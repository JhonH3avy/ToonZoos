using System;

namespace Menu.Characters
{
	public enum Characters
	{
		None,
		Bull,
		Chamaleon,
		Cocodrile,
		Eagle,
		Porcupine,
		Snail,
		Spider,
		Tiger,
		Wolf
	}
}

