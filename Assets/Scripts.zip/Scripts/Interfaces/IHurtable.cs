using System;
using UnityEngine;

namespace Scripts.Interfaces
{
	public interface IHurtable
	{
		void SlowDown ();
	}
}

