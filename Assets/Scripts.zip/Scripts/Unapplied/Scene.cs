using System;

namespace Scenes
{
	public enum Scene
	{
		Menu,
		Test
	}
}

